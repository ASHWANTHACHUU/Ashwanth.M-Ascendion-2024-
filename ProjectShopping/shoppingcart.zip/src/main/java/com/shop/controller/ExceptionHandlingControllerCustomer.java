//package com.shop.controller;
//
//import com.shop.exception.CustomerNotFoundException;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.ExceptionHandler;
//import org.springframework.web.bind.annotation.ResponseStatus;
//import org.springframework.web.bind.annotation.RestControllerAdvice;
//import org.springframework.web.context.request.WebRequest;
//
//@RestControllerAdvice
//public class ExceptionHandlingControllerCustomer {
//    @ResponseStatus(code = HttpStatus.BAD_REQUEST)
//    @ExceptionHandler({CustomerNotFoundException.class})
//    public ResponseEntity<?> handleCustomerNotFoundException(CustomerNotFoundException ex, WebRequest request){
//        return new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND);
//    }
//}
