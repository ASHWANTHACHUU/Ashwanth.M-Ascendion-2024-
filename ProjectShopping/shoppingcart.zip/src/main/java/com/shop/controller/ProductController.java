package com.shop.controller;

import com.shop.dto.Product;
import com.shop.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/shop/product")
public class ProductController {
    @Autowired
    private ProductService productService;

    @GetMapping("/display")
    public List<Product> getProducts() {
        return productService.getAllProducts();
    }
    @GetMapping("/id/{productId}")
    public List<Product> getProductById(@PathVariable("productId") int productId) {
        return productService.getProductById(productId);
    }
    @GetMapping("category")
    public List<Product> getProductsByCategory(@PathVariable("category") String category) {
        return productService.findByCategory(category);
    }
    @GetMapping("/{productName}")
    public List<Product> getProductsByProductName(@RequestParam("productName") String productName) {
        return productService.findByProductName(productName);
    }
    @GetMapping("/key/{productName}")
    public List<Product> getProductNameBySingleCharacter(@PathVariable("productName") String productName) {
        return productService.findByProductNameContainingIgnoreCase(productName);
    }
    @PutMapping("/update")
    public Product updateProduct(@RequestBody Product product) {
        return productService.updateProduct(product);
    }
    @PostMapping("/add")
    public Product addProduct(@RequestBody Product product) {
        return productService.saveProduct(product);
    }
    @DeleteMapping("/{productId}")
    public void deleteProductByProductId(@PathVariable("productId") int productId) {
        productService.deleteProductByProductId(productId);
    }
}
