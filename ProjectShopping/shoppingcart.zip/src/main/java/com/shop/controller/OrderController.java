package com.shop.controller;

import com.shop.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/shop/orders")
public class OrderController {
    @Autowired
    OrderService orderService;

    @PostMapping("/directorder")
    public void orderNow(@RequestParam int customerId,@RequestParam int productId){
         orderService.addOrderFromProduct(customerId,productId);
    }

    @PostMapping("/addorder")
    public void addOrder(@RequestParam int customerId,@RequestParam int cartItemId){
        orderService.addOrder(customerId,cartItemId);
    }

    @DeleteMapping
    public void deleteProductFromOrder(@RequestParam int customerId,@RequestParam int productId){
        orderService.deleteProductFromOrder(customerId,productId);
    }
}
