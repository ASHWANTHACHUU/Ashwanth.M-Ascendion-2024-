package com.shop.service;

//import com.shop.exception.CustomerNotFoundException;
import com.shop.repo.CustomerRepo;
import com.shop.dto.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    CustomerRepo customerRepo;
    @Override
    public Customer saveCustomer(Customer customer) {
        return customerRepo.save(customer);
    }

    @Override
    public List<Customer> getAllCustomers() {
        List<Customer> list= customerRepo.findAll();
        return list;
    }

    @Override
    public Customer updateCustomer(Customer customer) {
//        if(!customerRepo.existsById(customer.getCustomerId())){
//            throw new CustomerNotFoundException("CustomerNotFound so we cant update");
//        }
        return customerRepo.save(customer);
    }

    @Override
    public void deleteCustomerById(int customerId) {
//        if!(customerRepo.existsById(customerId)){
//            throw new CustomerNotFoundException("Customer not found");
//        }
        customerRepo.deleteById(customerId);
    }

    @Override
    public Customer findCustomerByCustomerId(int customerId) {
        return customerRepo.findCustomerByCustomerId(customerId);
    }

    @Override
    public Customer findCustomerByCustomerName(String customerName) {
        return customerRepo.findCustomerByCustomerName(customerName);
    }

    @Override
    public Customer findCustomerByCustomerCity(String customerCity) {
        return customerRepo.findCustomerByCustomerCity(customerCity);
    }

    @Override
    public Customer findCustomerByCustomerPinCode(int customerPinCode) {
        return customerRepo.findCustomerByCustomerPinCode(customerPinCode);
    }
}
