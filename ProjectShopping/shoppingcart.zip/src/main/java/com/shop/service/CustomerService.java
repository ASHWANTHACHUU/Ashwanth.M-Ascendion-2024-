package com.shop.service;

import com.shop.dto.Customer;

import java.util.List;

public interface CustomerService {
    public Customer saveCustomer(Customer customer) ; //create
    public List<Customer> getAllCustomers(); //read
    public Customer updateCustomer(Customer customer);
    public void deleteCustomerById(int customerId); // delete
    public Customer findCustomerByCustomerId(int customerId);
    public Customer findCustomerByCustomerName(String customerName);
    public Customer findCustomerByCustomerCity(String customerCity);
    public Customer findCustomerByCustomerPinCode(int customerPinCode);
}
