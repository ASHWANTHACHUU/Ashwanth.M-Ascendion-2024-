package com.shop.service;

import com.shop.repo.ProductRepo;
import com.shop.dto.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepo productRepo;
    @Override
    public Product saveProduct(Product product) {
        return productRepo.save(product);
    }

    @Override
    public List<Product> getAllProducts() {
        List<Product> products = productRepo.findAll();
        return products;
    }

    @Override
    public Product updateProduct(Product product) {
        return productRepo.save(product);
    }

    @Override
    public List<Product> getProductById(int productId) {
        return productRepo.findByProductId(productId);
    }

    @Override
    public void deleteProductByProductId(int productId) {
        productRepo.deleteById(productId);
    }

    @Override
    public List<Product> findByProductName(String productName) {
        return productRepo.findByProductName(productName);
    }

    @Override
    public List<Product> findByCategory(String category) {
        return productRepo.findByCategory(category);
    }

    @Override
    public List<Product> findByProductNameContainingIgnoreCase(String productName) {
        return productRepo.findByProductNameContainingIgnoreCase(productName);
    }
}
