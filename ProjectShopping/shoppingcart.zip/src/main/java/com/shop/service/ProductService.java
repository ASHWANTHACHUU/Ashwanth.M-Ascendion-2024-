package com.shop.service;

import com.shop.dto.Product;

import java.util.List;

public interface ProductService {
    public Product saveProduct(Product product);
    public List<Product> getAllProducts();
    public Product updateProduct(Product product);
    public List<Product> getProductById(int productId);
    public void deleteProductByProductId(int productId);
    public List<Product> findByProductName(String productName);
    public List<Product> findByCategory(String category);
    public List<Product> findByProductNameContainingIgnoreCase(String productName);
}
