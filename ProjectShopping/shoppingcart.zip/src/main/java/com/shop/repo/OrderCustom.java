package com.shop.repo;

import jakarta.persistence.criteria.Order;

public interface OrderCustom {

    public void addOrderFromProduct(int customerId,int productId);
    public void addOrder(int customerId, int cartItemId);
    public void deleteProductFromOrder(int customerId,int productId);
    public void cancelOrder(int customerId,int productId);
}
