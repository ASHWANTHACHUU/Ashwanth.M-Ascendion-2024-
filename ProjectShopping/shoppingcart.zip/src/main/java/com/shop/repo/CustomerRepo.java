package com.shop.repo;

import com.shop.dto.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepo extends JpaRepository<Customer, Integer> {
    public Customer findCustomerByCustomerId(int customerId);
    public Customer findCustomerByCustomerName(String customerName);
    public Customer findCustomerByCustomerCity(String customerCity);
    public Customer findCustomerByCustomerPinCode(int customerPinCode);
}
