package com.shop.repo;

import com.shop.dto.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.Order;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class OrderCustomImpl implements OrderCustom {

    @PersistenceContext
    @Autowired
    EntityManager em;



    @Transactional
    @Override
    public void addOrderFromProduct(int customerId, int productId) {
        Customer customer = em.find(Customer.class, customerId);
        Product product = em.find(Product.class, productId);
        Orders orders = new Orders();
        orders.setCustomerId(customerId);
        orders.setTotal(product.getPrice());
        List<OrderLineItem> orderLineItemList = new ArrayList<>();
//        order.setCustomerId(customerId);
//        order.setTotal(product.getPrice());
        OrderLineItem orderLineItem=new OrderLineItem();
        orderLineItem.setProduct(product);
        orderLineItem.setOrderProductId(productId);
        orderLineItem.setOrderProductQuantity(1);
        orderLineItem.setOrderProductPrice(product.getPrice());
        orderLineItem.setOrderProductTotal(product.getPrice());
        orderLineItem.setOrderStatus(true);
        em.persist(orderLineItem);
        orderLineItemList.add(orderLineItem);
        orders.setOrderLineItemList(orderLineItemList);
        customer.setOrders(orders);
        em.persist(orders);
        em.persist(customer);
        product.setProductQuantity(product.getProductQuantity()-1);
        em.persist(product);
    }

    @Transactional
    @Override
    public void addOrder(int customerId, int cartItemId) {
        Customer customer = em.find(Customer.class, customerId);
        CartItem cartItem = em.find(CartItem.class, cartItemId);
        Orders orders = customer.getOrders();
        if (orders==null){
            orders = new Orders();
            orders.setCustomerId(customerId);
            orders.setTotal(orders.getTotal()+cartItem.getPrice());
            List<OrderLineItem> orderLineItemList = new ArrayList<>();
            OrderLineItem orderLineItem=new OrderLineItem();
            orderLineItem.setOrderProductId(cartItem.getProduct().getProductId());
            orderLineItem.setProduct(cartItem.getProduct());
            orderLineItem.setOrderProductQuantity(cartItem.getProduct().getProductQuantity());
            orderLineItem.setOrderProductPrice(cartItem.getPrice());
            orderLineItem.setOrderProductTotal(cartItem.getTotalPrice());
            orderLineItem.setOrderStatus(true);
            em.persist(orderLineItem);
            orderLineItemList.add(orderLineItem);
            orders.setOrderLineItemList(orderLineItemList);
        }
        else{
            List<OrderLineItem> orderLineItemList = orders.getOrderLineItemList();
            boolean found = false;
            int orderLineItemId = 0;
            for (OrderLineItem orderLineItem : orderLineItemList) {
                if(orderLineItem.getProduct()==cartItem.getProduct()){
                    found = true;
                    orderLineItemId=orderLineItem.getOrderLineItemId();
                }
            }
            if(found){
                for (OrderLineItem orderLineItem : orderLineItemList) {
                    if(orderLineItem.getOrderLineItemId()==orderLineItemId){
                        orderLineItem.setOrderProductQuantity(orderLineItem.getOrderProductQuantity()+cartItem.getProduct().getProductQuantity());
                        orderLineItem.setOrderProductTotal(orderLineItem.getOrderProductTotal()+cartItem.getProduct().getPrice());
                        orderLineItem.setOrderStatus(true);
                        break;
                    }
                }
                orders.setTotal(orders.getTotal()+cartItem.getPrice());
                orders.setOrderLineItemList(orderLineItemList);
            }
            else{
                orders.setTotal(orders.getTotal()+cartItem.getPrice());
                OrderLineItem orderLineItem=new OrderLineItem();
                orderLineItem.setOrderProductId(cartItem.getProduct().getProductId());
                orderLineItem.setOrderProductQuantity(cartItem.getProduct().getProductQuantity());
                orderLineItem.setOrderProductPrice(cartItem.getPrice());
                orderLineItem.setProduct(cartItem.getProduct());
                orderLineItem.setOrderProductTotal(cartItem.getTotalPrice());
                orderLineItem.setOrderStatus(true);
                em.persist(orderLineItem);
                orders.getOrderLineItemList().add(orderLineItem);
            }
        }
        customer.setOrders(orders);
        Cart cart=customer.getCart();
        List<CartItem> cartItemList=cart.getCartItem();
        cartItemList.remove(cartItem);
        em.persist(customer);
        Product product=em.find(Product.class, cartItem.getProduct().getProductId());
        product.setProductQuantity(product.getProductQuantity()-cartItem.getProduct().getProductQuantity());
        em.persist(product);
    }

    @Transactional
    @Override
    public void deleteProductFromOrder(int customerId, int productId) {
        Customer customer=em.find(Customer.class, customerId);
        Product product=em.find(Product.class, productId);
        Orders orders=customer.getOrders();
        List<OrderLineItem> orderLineItemList=orders.getOrderLineItemList();
        for (OrderLineItem orderLineItem : orderLineItemList) {
            if(orderLineItem.getProduct().getProductId()==productId){
                if(orderLineItem.getOrderProductQuantity()>1){
                    orderLineItem.setOrderProductTotal(orderLineItem.getOrderProductTotal()-product.getProductQuantity());
                    orderLineItem.setOrderProductQuantity(orderLineItem.getOrderProductQuantity()-1);
                }
                else{
                    orderLineItemList.remove(orderLineItem);
                }
                break;
            }
        }
        orders.setTotal(orders.getTotal()-product.getPrice());
        customer.setOrders(orders);
        em.persist(customer);
        product.setProductQuantity(product.getProductQuantity()+1);
        em.persist(product);
    }

    @Transactional
    @Override
    public void cancelOrder(int customerId, int productId) {
        Customer customer = em.find(Customer.class, customerId);
        Product product = em.find(Product.class, productId);
        Orders orders = customer.getOrders();
        List<OrderLineItem> orderLineItemList = orders.getOrderLineItemList();
        for (OrderLineItem orderLineItem : orderLineItemList) {
            if(orderLineItem.getProduct().getProductId()==productId){
                product.setProductQuantity(product.getProductQuantity()-orderLineItem.getOrderLineItemId());
                orderLineItem.setOrderProductTotal(orders.getTotal()-orderLineItem.getOrderLineItemId());
                orderLineItemList.remove(orderLineItem);
                break;
            }
        }
        orders.setOrderLineItemList(orderLineItemList);
        customer.setOrders(orders);
        em.persist(customer);
        em.persist(product);
    }

}




