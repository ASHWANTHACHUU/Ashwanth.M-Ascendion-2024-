package com.shop.repo;

import com.shop.dto.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepo extends JpaRepository<Product, Integer> {
    public List<Product> findByProductName(String productName);
    public List<Product> findByProductId(int productId);
    public List<Product> findByCategory(String category);
    public List<Product> findByProductNameContainingIgnoreCase(String productName);
}
