//package com.shop.service;
//
//import com.shop.repo.OrderRepo;
//import com.shop.dto.Order;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.sql.Date;
//import java.util.List;
//@Service
//public class OrderServiceImpl implements OrderService {
//
//    @Autowired
//    private OrderRepo orderRepo;
//
//    @Override
//    public Order addOrder(int customerId, int cartItemId) {
//        return orderRepo.addOrder(customerId,cartItemId);
//    }
//
//    @Override
//    public void addOrderFromProduct(int customerId, int productId) {
//        orderRepo.addOrderFromProduct(customerId,productId);
//    }
//
//    @Override
//    public void deleteProductFromOrder(int customerId, int productId) {
//        orderRepo.deleteProductFromOrder(customerId,productId);
//    }
//
//    @Override
//    public void cancelOrder(int customerId, int productId) {
//        orderRepo.cancelOrder(customerId,productId);
//    }
//}
