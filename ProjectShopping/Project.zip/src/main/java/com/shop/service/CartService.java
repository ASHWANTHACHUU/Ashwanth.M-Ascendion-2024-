package com.shop.service;

import com.shop.dto.Cart;
import com.shop.dto.Customer;

import java.util.List;

public interface CartService {
    public void addToCart(int customerId, int productId);
    public String updateToCart(int customerId, int productId);//4
    public Cart getCartById(int customerId);//2
    public String removeAllProducts(int customerId);
    public List<Cart> displayAllCart();
}
