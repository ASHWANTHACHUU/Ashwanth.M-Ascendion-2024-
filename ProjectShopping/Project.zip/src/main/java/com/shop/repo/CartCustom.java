package com.shop.repo;

import com.shop.dto.Cart;
import com.shop.dto.CartItem;
import com.shop.dto.Customer;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface CartCustom {
    public void addToCart(int customerId, int productId);//1
    public String updateToCart(int customerId, int productId);//4
    public Cart getCartById(int customerId);//2
    public String removeAllProducts(int customerId);
    public List<Cart> displayAllCart(); //3
//    public List<CartItem> getCart(int customerId);
//    public void removeFromCart(int customerId);
//    public void deleteCartItem(int customerId, int productId);
//    public void displayCart(Customer customer);

}
