package com.shop.repo;

import com.shop.dto.Cart;
import com.shop.dto.CartItem;
import com.shop.dto.Customer;
import com.shop.dto.Product;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Repository
public class CartCustomImpl implements CartCustom {

    @PersistenceContext
     EntityManager em;

   @Autowired
   CartRepo cartRepo;

    @Transactional
    @Override
    public void addToCart(int customerId, int productId) {
        Customer customer = em.find(Customer.class,customerId);
        Cart cart = customer.getCart();
        if(cart!=null) {
            Product product1=em.find(Product.class,productId);
            List<CartItem> cartItemList=cart.getCartItem();
            boolean found=false;
            int cartItemId=0;
            for(CartItem cartItem:cartItemList){
                if(cartItem.getProduct()==product1){
                    cartItemId=cartItem.getCartItemId();
                    found=true;
                    break;
                }
            }
            if(found){
                for(CartItem cartItem:cartItemList){
                    if(cartItem.getCartItemId()==cartItemId){
                        cartItem.setTotalPrice(cartItem.getTotalPrice()+cartItem.getPrice());
                        cartItem.setQuantity(cartItem.getQuantity()+1);
                    }
                }
            }
            else{
                CartItem cartItem=new CartItem();
                cartItem.setProduct(product1);
                cartItem.setQuantity(1);
                cartItem.setTotalPrice(product1.getPrice());
                cartItem.setPrice(product1.getPrice());
                cart.getCartItem().add(cartItem);
                em.persist(cartItem);
            }
            em.persist(cart);
            customer.setCart(cart);
            em.persist(customer);

        }
        else{
            Cart cart2=new Cart();
            cart2.setCustomer(customer);
            Product product1=em.find(Product.class,productId);
            List<CartItem> cartItemList= new ArrayList<>();
            CartItem cartItem=new CartItem();
            cartItem.setProduct(product1);
            cartItem.setQuantity(1);
            cartItem.setTotalPrice(product1.getPrice());
            cartItem.setPrice(product1.getPrice());
            cartItemList.add(cartItem);
            em.persist(cartItem);
            cart2.setCartItem(cartItemList);
            em.persist(cart2);
            customer.setCart(cart2);
            em.persist(customer);
        }
    }
    @Transactional
    @Override
    public String updateToCart(int customerId, int productId) {
        Customer customer = em.find(Customer.class, customerId);
        Cart cart = customer.getCart();
        if (cart != null) {
            Product product1 = em.find(Product.class, productId);
            List<CartItem> cartItemList = cart.getCartItem();
            boolean found = false;
            int cartItemId = 0;
            for (CartItem cartItem : cartItemList) {
                if (cartItem.getProduct() == product1) {
                    cartItemId = cartItem.getCartItemId();
                    found = true;
                    break;
                }
            }
            if (found) {
                for (CartItem cd : cartItemList) {
                    if (cd.getCartItemId() == cartItemId) {

                        if(cd.getQuantity()>0) {
                            cd.setTotalPrice(cd.getTotalPrice() - cd.getPrice());
                            cd.setQuantity(cd.getQuantity() - 1);
                        }
                        else{
                            String sql="DELETE FROM CartItem where quantity<=0";
                            Query q=em.createNativeQuery(sql);
                            q.executeUpdate();
                            return "your product quantity is already zero";
                        }
                    }
                }

                return "updated successfully";
            }
            customer.setCart(cart);
            em.persist(customer);

        }
        return "cart not found";

    }

    @Transactional
    @Override
    public Cart getCartById(int customerId) {
        Customer customer = em.find(Customer.class,customerId);
        Cart cart = customer.getCart();
        return cart;
    }

    @Override
    @Transactional
    public String removeAllProducts(int customerId) {
        Customer customer = em.find(Customer.class, customerId);
        Cart cart= customer.getCart();
        if(cart!=null) {
            customer.getCart().setCartItem(null);
            em.persist(customer);
            return "your cart is removed";
            //return "your cart is already empty";
        }
//                                        ( customer.getCart().setCartItem(null);
//                                         em.persist(customer);)
        return "your cart is already empty";
//        Cart cart = customer.getCart();

//        if (cart != null) {
//            List<CartItem> cp = cart.getCartItem();
//            boolean found = true;
//            for (CartItem cartItem : cp) {
//                if (cartItem.getProduct() == null) {
//                    found = false;
//                    break;
//                }
//            }
//            if (found) {
//                String sql="DELETE FROM CartItem";
//                Query q=em.createNativeQuery(sql);
//                q.executeUpdate();
//                return "your cart is empty";
//            }
//        }
    }

    @Override
    public List<Cart> displayAllCart() { //
        return cartRepo.findAll();
    }
}

