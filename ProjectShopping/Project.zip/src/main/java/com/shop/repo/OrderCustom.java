//package com.shop.repo;
//
//import com.shop.dto.Order;
//
//public interface OrderCustom {
//    public Order addOrder(int customerId, int cartItemId);
//    public void addOrderFromProduct(int customerId,int productId);
//    public void deleteProductFromOrder(int customerId,int productId);
//    public void cancelOrder(int customerId,int productId);
//}
