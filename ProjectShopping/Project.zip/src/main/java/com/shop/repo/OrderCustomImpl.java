//package com.shop.repo;
//
//import com.shop.dto.Customer;
//import com.shop.dto.Order;
//import com.shop.dto.OrderLineItem;
//import com.shop.dto.Product;
//import jakarta.persistence.EntityManager;
//import jakarta.persistence.PersistenceContext;
//import jakarta.transaction.Transactional;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Repository;
//
//import java.util.ArrayList;
//import java.util.List;
//
//@Repository
//public class OrderCustomImpl implements OrderCustom {
//
//
//    @PersistenceContext
//    EntityManager em;
//
//    @Autowired
//    OrderRepo orderRepo;
//
//    @Transactional
//    @Override
//    public Order addOrder(int customerId, int cartItemId) {
//        return null;
//    }
//
//    @Transactional
//    @Override
//    public void addOrderFromProduct(int customerId, int productId) {
//        Customer customer=em.find(Customer.class,customerId);
//        Product product=em.find(Product.class,productId);
//        Order order=customer.getOrder();
//        if(order==null){
//            order=new Order();
//            List<OrderLineItem> orderLineItemList=new ArrayList<>();
//            order.setCustomerId(customerId);
//            order.setOrderId(order.getOrderId());
//            order.setTotal(product.getPrice());
//            OrderLineItem orderLineItem=new OrderLineItem();
//            orderLineItem.setOrderProductId(product.getProductId());
//            orderLineItem.setProduct(product);
//            orderLineItem.setOrderProductQuantity(1);
//            orderLineItem.setOrderProductPrice(product.getPrice());
//            orderLineItem.setOrderProductTotal(product.getPrice());
//            orderLineItem.setOrderStatus(true);
//            em.persist(orderLineItem);
//            orderLineItemList.add(orderLineItem);
//            order.setOrderLineItemList(orderLineItemList);
//        }
//        else{
//            order.setTotal(order.getTotal()+product.getPrice());
//            OrderLineItem orderLineItem=new OrderLineItem();
//            orderLineItem.setOrderProductId(product.getProductId());
//            orderLineItem.setOrderProductQuantity(1);
//            orderLineItem.setProduct(product);
//            orderLineItem.setOrderProductPrice(product.getPrice());
//            orderLineItem.setOrderProductTotal(product.getPrice());
//            orderLineItem.setOrderStatus(true);
//            em.persist(orderLineItem);
//            order.getOrderLineItemList().add(orderLineItem);
//        }
//        customer.setOrder(order);
//        em.persist(customer);
//        product.setProductQuantity(product.getProductQuantity() -1);
//        em.persist(product);
//    }
//
//    @Override
//    public void deleteProductFromOrder(int customerId, int productId) {
//
//    }
//
//    @Override
//    public void cancelOrder(int customerId, int productId) {
//
//    }
//}
