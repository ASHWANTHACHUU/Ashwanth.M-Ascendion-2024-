//package com.shop.dto;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.Id;
//import jakarta.persistence.ManyToOne;
//import lombok.*;
//
//@Entity
//@Setter
//@Getter
//@NoArgsConstructor
//@AllArgsConstructor
//@ToString
//@EqualsAndHashCode
//public class OrderLineItem {
//    @Id
//    private int orderLineItemId;
//    private int orderProductId;
//    private int orderProductQuantity;
//
//    @ManyToOne
//    Product product;
//    private int orderProductPrice;
//    private int orderProductTotal;
//    private boolean orderStatus;
//}
